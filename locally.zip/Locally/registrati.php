<?php
// Inizializza le variabili
$nome = $cognome = $email = $password = $conferma_password = "";
$error = "";

// Verifica se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera e pulisce i dati del form
    $nome = trim($_POST["nome"]);
    $cognome = trim($_POST["cognome"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $conferma_password = $_POST["conferma-password"];
    $login_type = isset($_POST['l_u']) ? $_POST['l_u'] : '';
     if ( ($login_type === 'UNLOCAL') ){
    $table = 'local_u';
    }else{
    $table = 'unlocal_u';
    }
    
    
    // Validazione base
    if (empty($nome) || empty($cognome) || empty($email) || empty($password) || empty($conferma_password)) {
        $error = "Tutti i campi sono obbligatori";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Formato email non valido";
    } elseif (strlen($password) < 8) {
        $error = "La password deve contenere almeno 8 caratteri";
    }elseif($login_type ===""){
        $error = "è obbligatorio selezionare un tipo di login";
    } elseif(empty($login_type)){
        $error = "è obbligatorio selezionare un tipo di login";
    } elseif (!preg_match("/[A-Z]/", $password)) {
        $error = "La password deve contenere almeno una lettera maiuscola";
    } elseif (!preg_match("/[0-9]/", $password)) {
        $error = "La password deve contenere almeno un numero";
    } elseif ($password !== $conferma_password) {
        $error = "Le password non corrispondono";
    } elseif (!isset($_POST["accetta-termini"])) {
        $error = "Devi accettare i Termini di Servizio e l'Informativa sulla Privacy";
    } else {
        // Esempio di connessione al database (da personalizzare con i tuoi parametri)
        //$conn = new mysqli("sql7.freesqldatabase.com", "sql7780058", "SwidxqPSdb", "sql7780058");
        $conn = new mysqli("localhost", "root", "", "my_locally");
        
        // Verifica la connessione
        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }
        
        // Verifica se l'email è già registrata
        $stmt = $conn->prepare("SELECT id FROM $table WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = "Email già registrata. Prova con un'altra email.";
        } else {
            // Inserisci il nuovo utente nel database
            $stmt = $conn->prepare("INSERT INTO $table (nome, email, `password`) VALUES ( ?, ?, ?)");
            if ($stmt === false) {
                die("Prepare failed: " . $conn->error);
            }
            // Hash della password per sicurezza
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt->bind_param("sss", $nome, $email, $password_hash);
            
            if ($stmt->execute()) {
                // Registrazione riuscita, avvia la sessione
                $registr = "Registrazione completata con successo!";
                session_start();
                $_SESSION["user_id"] = $conn->insert_id;
                $_SESSION["email"] = $email;
                $_SESSION["nome"] = $nome;
                
                // Reindirizza alla pagina dashboard o home
                
            } else {
                $error = "Errore durante la registrazione: " . $stmt->error;
            }
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locally•Registrazione</title>
    <link rel="icon" type="image/x-icon" href="logo.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
           background: #efe9e2;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .container {
            
            margin-top: 90px;
            border-radius: 10px;
           
            width: 420px;
            max-width: 100%;
            overflow: hidden;
            padding: 30px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #666;
            font-size: 16px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            gap: 15px;
        }
        
        .form-row .form-group {
            flex: 1;
        }
        
        .form-group label {
            display: block;
            color: #444;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            border-color: #764ba2;
            outline: none;
        }
        
        .privacy-terms {
            margin-bottom: 20px;
            font-size: 14px;
            color: #666;
        }
        
        .privacy-terms label {
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }
        
        .privacy-terms input {
            margin-top: 3px;
        }
        
        .privacy-terms a {
            color: #764ba2;
            text-decoration: none;
        }
        
        .privacy-terms a:hover {
            text-decoration: underline;
        }
        
        .btn {
            background: #5b5c38;
            color: white;
            border: none;
            padding: 12px 0;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        select {
        padding: 10px;
        font-size: 16px;
        border-radius: 8px;
        border: 1px solid #ccc;
        margin-top: 10px;
        width: 200px;
        background-color: #fff;
    }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 14px rgba(0, 0, 0, 0.1);
        }
        
        .login {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        
        .login a {
            color: #764ba2;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login a:hover {
            text-decoration: underline;
        }
        
        .password-requirements {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }
        
        .error-message {
            background-color: #ffe6e6;
            color: #d33;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }
        .registr-message {
            background-color:rgb(237, 255, 230);
            color: #d33;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }
        .sinistra{
            position: absolute;
            top: 0;
            left: 0;
            width: auto;
            height: 80%;
            background-image: url('sinistra.jpg');
            background-size: cover;
            background-position: center;
        }
        .destra{
            position: absolute;
            bottom: 0;
            right: 0;
            width: auto;
            height: 80%;
            background-image: url('destra.jpg');
            background-size: cover;
            background-position: center;
        }
        .titolo{
            position: absolute;
            top: 0;
            left: 42%;
            
            width: auto;
            height: 10%;
            
        }
    </style>
</head>
<body>
    <img src="titolo.jpg" class="titolo" alt="">
    <img src="sinistra.jpg" class="sinistra" alt="">
    <img src="destra.jpg" class="destra" alt="">
    <div class="container">
        <div class="header">
            <h1>Crea un account</h1>
            <p>Inserisci i tuoi dati per registrarti</p>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($registr)): ?>
            <div class="registr-message">
                <?php echo htmlspecialchars($registr); ?>
            </div>
        <?php endif; ?>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-row">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" id="nome" name="nome" placeholder="Il tuo nome" value="<?php echo htmlspecialchars($nome); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="cognome">Cognome</label>
                    <input type="text" id="cognome" name="cognome" placeholder="Il tuo cognome" value="<?php echo htmlspecialchars($cognome); ?>" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="genere">LOCAL o UNLOCAL:</label>
                <select id="l_u" name="l_u">
                <option value="LOCAL">Unlocal</option>
                <option value="UNLOCAL">Local</option>
                </select>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="La tua email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Crea una password" required>
                <div class="password-requirements">
                    La password deve contenere almeno 8 caratteri, una lettera maiuscola e un numero
                </div>
            </div>
            
            <div class="form-group">
                <label for="conferma-password">Conferma Password</label>
                <input type="password" id="conferma-password" name="conferma-password" placeholder="Conferma la tua password" required>
            </div>
            
            <div class="privacy-terms">
                <label>
                    <input type="checkbox" name="accetta-termini" required>
                    <span>Accetto i <a href="#">Termini di Servizio</a> e l'<a href="#">Informativa sulla Privacy</a></span>
                </label>
            </div>
            
            <button type="submit" class="btn">Registrati</button>
            
            <div class="login">
                Hai già un account? <a href="index.php">Accedi</a>
            </div>
        </form>
    </div>
</body>
</html>