<?php
// Inizializza le variabili
$email = "";
$message = "";
$message_type = "";

// Verifica se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera e pulisce l'email dal form
    $email = trim($_POST["email"]);
    
    // Validazione base
    if (empty($email)) {
        $message = "Inserisci la tua email";
        $message_type = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Formato email non valido";
        $message_type = "error";
    } else {
        // Connessione al database (da personalizzare con i tuoi parametri)
        //$conn = new mysqli("sql7.freesqldatabase.com", "sql7780058", "SwidxqPSdb", "sql7780058");
        $conn = new mysqli("localhost", "root", "", "my_locally");
        
        // Verifica la connessione
        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }
        
        $user = null;
$stmt = $conn->prepare("SELECT nome FROM local_u WHERE id = ?");
if (!$stmt) {
    die("Errore nella query local_u: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    $stmt = $conn->prepare("SELECT nome FROM unlocal_u WHERE id = ?");
    if (!$stmt) {
        die("Errore nella query unlocal_u: " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
    }
}

        
        if ($result->num_rows == 0) {
            // Non mostriamo all'utente se l'email esiste o meno (per sicurezza)
            $message = "Se la tua email è registrata, riceverai un link per reimpostare la password";
            $message_type = "success";
        } else {
            // L'email esiste, genera token di reset
            $user = $result->fetch_assoc();
            $user_id = $user["id"];
            
            // Genera un token casuale
            $token = bin2hex(random_bytes(32));
            
            // Calcola la scadenza (24 ore da adesso)
            $expiry = date("Y-m-d H:i:s", time() + 86400);
            
            // Elimina eventuali token esistenti per questo utente
            $stmt = $conn->prepare("DELETE FROM password_reset WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            
            // Inserisci il nuovo token
            $stmt = $conn->prepare("INSERT INTO password_reset (user_id, token, scadenza) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $user_id, $token, $expiry);
            
            if ($stmt->execute()) {
                // Costruisci l'URL di reset
                $reset_url = "https://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset-password.php?token=" . $token;
                
                // Qui dovresti inviare l'email con il link di reset
                // Nota: in un ambiente reale, usare una libreria come PHPMailer
                // Questo è un esempio semplificato
                $to = $email;
                $subject = "Recupero Password";
                $message_body = "Ciao,\n\n";
                $message_body .= "Hai richiesto di reimpostare la tua password. Clicca sul link seguente per procedere:\n\n";
                $message_body .= $reset_url . "\n\n";
                $message_body .= "Il link sarà valido per 24 ore.\n\n";
                $message_body .= "Se non hai richiesto questo reset, ignora questa email.\n\n";
                $message_body .= "Cordiali saluti,\nIl Team";
                
                $headers = "From: noreply@tuosito.com\r\n";
                
                // In ambiente di produzione, abilita questa riga per inviare l'email
                mail($to, $subject, $message_body, $headers);
                
                // Per scopi di test, mostra l'URL di reset
                // RIMUOVERE IN PRODUZIONE - questo è solo per test
                //$message = "Link di reset generato: " . $reset_url;
               // $message_type = "success";
                
                // In produzione, usa questo messaggio invece
                // $message = "Se la tua email è registrata, riceverai un link per reimpostare la password";
                // $message_type = "success";
            } else {
                $message = "Si è verificato un errore. Riprova più tardi.";
                $message_type = "error";
            }
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recupera Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
            width: 380px;
            max-width: 100%;
            overflow: hidden;
            padding: 30px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #666;
            font-size: 16px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #444;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            border-color: #764ba2;
            outline: none;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            padding: 12px 0;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 14px rgba(0, 0, 0, 0.1);
        }
        
        .login-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        
        .login-link a {
            color: #764ba2;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }
        
        .message.error {
            background-color: #ffe6e6;
            color: #d33;
        }
        
        .message.success {
            background-color: #e6ffe6;
            color: #3c763d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Recupera Password</h1>
            <p>Inserisci la tua email per reimpostare la password</p>
        </div>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Inserisci la tua email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            
            <button type="submit" class="btn">Invia link di recupero</button>
            
            <div class="login-link">
                Ricordi la password? <a href="index.php">Accedi</a>
            </div>
        </form>
    </div>
</body>
</html>