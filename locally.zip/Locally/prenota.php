<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit();
}

$messaggio = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ristorante = trim($_POST["ristorante"]);
    $data = $_POST["data"];
    $ora = $_POST["ora"];
    $user_id = $_SESSION["user_id"];

    if ($ristorante && $data && $ora) {
        $conn = new mysqli("localhost", "root", "", "my_locally");
        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }
        $stmt = $conn->prepare("INSERT INTO prenotazioni (user_id, ristorante, data, ora, stato) VALUES (?, ?, ?, ?, 'confermata')");
        $stmt->bind_param("isss", $user_id, $ristorante, $data, $ora);
        if ($stmt->execute()) {
            $messaggio = "Prenotazione effettuata con successo!";
        } else {
            $messaggio = "Errore durante la prenotazione: " . $conn->error;
        }
        $stmt->close();
        $conn->close();
    } else {
        $messaggio = "Compila tutti i campi!";
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Prenota un ristorante - Locally</title>
    <link rel="icon" type="image/x-icon" href="logo.jpg">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #efe9e2;
            margin: 0;
            min-height: 100vh;
            position: relative;
        }
        .header-logo {
            width: 180px;
            display: block;
            margin: 30px auto 10px auto;
        }
        .slogan {
            text-align: center;
            font-size: 2em;
            color: #5b5c38;
            font-style: italic;
            margin-bottom: 30px;
        }
        .container {
            max-width: 700px;
            margin: 0 auto 40px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
            padding: 30px;
            position: relative;
            z-index: 2;
        }
        .logout {
            float: right;
            background: #764ba2;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group {
            margin-bottom: 18px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            color: #5b5c38;
        }
        input, select {
            width: 100%;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1em;
        }
        .submit-btn {
            background: #5b5c38;
            color: #fff;
            border: none;
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        .messaggio {
            margin-bottom: 18px;
            color: #764ba2;
            font-weight: bold;
            text-align: center;
        }
        /* Immagini decorative */
        .img-sinistra {
            position: absolute;
            top: 80px;
            left: 0;
            width: 180px;
            border-radius: 0 0 40px 0;
            z-index: 1;
        }
        .img-destra {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 300px;
            border-radius: 40px 0 0 0;
            z-index: 1;
        }
        .img-foto {
            position: absolute;
            top: 30px;
            right: 40px;
            width: 90px;
            opacity: 0.8;
            z-index: 3;
        }
        @media (max-width: 900px) {
            .container { max-width: 98vw; }
            .img-sinistra, .img-destra, .img-foto { display: none; }
            .header-logo { width: 90vw; }
        }
    </style>
</head>
<body>
    <img src="logo.png" alt="Locally Logo" class="header-logo">
    <div class="slogan">Eat like a local</div>
    <img src="foto.jpg" alt="Hand Logo" class="img-foto">
    <img src="sinistra.jpg" alt="Piatto 1" class="img-sinistra">
    <img src="destra.jpg" alt="Piatto 2" class="img-destra">

    <div class="container">
        <form action="logout.php" method="post" style="float:right;">
            <button class="logout" type="submit">Esci</button>
        </form>
        <h1>Prenota un ristorante</h1>
        <?php if ($messaggio): ?>
            <div class="messaggio"><?php echo htmlspecialchars($messaggio); ?></div>
        <?php endif; ?>
        <form method="post" autocomplete="off">
            <div class="form-group">
                <label for="ristorante">Nome ristorante</label>
                <input type="text" id="ristorante" name="ristorante" required>
            </div>
            <div class="form-group">
                <label for="data">Data</label>
                <input type="date" id="data" name="data" required>
            </div>
            <div class="form-group">
                <label for="ora">Ora</label>
                <input type="time" id="ora" name="ora" required>
            </div>
            <button class="submit-btn" type="submit">Prenota</button>
        </form>
        <a href="accesso.php" class="nuova-prenotazione" style="margin-top:20px;display:inline-block;">Torna all'area personale</a>
    </div>
</body>
</html>