<?php
// Inizializza le variabili
$token = "";
$password = "";
$conferma_password = "";
$message = "";
$message_type = "";
$token_valido = false;
$user_id = null;

// Verifica se è stato fornito un token tramite GET
if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $_GET['token'];
    
    // Connessione al database (da personalizzare con i tuoi parametri)
    //$conn = new mysqli("sql7.freesqldatabase.com", "sql7780058", "SwidxqPSdb", "sql7780058");
    $conn = new mysqli("localhost", "root", "", "my_locally");
    
    // Verifica la connessione
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }
    
    // Verifica se il token esiste ed è valido
    $stmt = $conn->prepare("SELECT user_id, scadenza FROM password_reset WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $reset_data = $result->fetch_assoc();
        $user_id = $reset_data["user_id"];
        $expiry = strtotime($reset_data["scadenza"]);
        
        // Verifica se il token è scaduto
        if ($expiry > time()) {
            $token_valido = true;
        } else {
            $message = "Il link per reimpostare la password è scaduto. Richiedi un nuovo link.";
            $message_type = "error";
        }
    } else {
        $message = "Link di reset non valido. Richiedi un nuovo link.";
        $message_type = "error";
    }
    
    $stmt->close();
    
    // Se è stato inviato il form per la nuova password
    if ($_SERVER["REQUEST_METHOD"] == "POST" && $token_valido) {
        $password = $_POST["password"];
        $conferma_password = $_POST["conferma-password"];
        
        // Validazione
        if (empty($password) || empty($conferma_password)) {
            $message = "Tutti i campi sono obbligatori";
            $message_type = "error";
        } elseif (strlen($password) < 8) {
            $message = "La password deve contenere almeno 8 caratteri";
            $message_type = "error";
        } elseif (!preg_match("/[A-Z]/", $password)) {
            $message = "La password deve contenere almeno una lettera maiuscola";
            $message_type = "error";
        } elseif (!preg_match("/[0-9]/", $password)) {
            $message = "La password deve contenere almeno un numero";
            $message_type = "error";
        } elseif ($password !== $conferma_password) {
            $message = "Le password non corrispondono";
            $message_type = "error";
        } else {
            // Aggiorna la password dell'utente
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE utenti SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $password_hash, $user_id);
            
            if ($stmt->execute()) {
                // Elimina il token usato
                $stmt = $conn->prepare("DELETE FROM password_reset WHERE user_id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                
                $message = "Password reimpostata con successo! Ora puoi accedere con la tua nuova password.";
                $message_type = "success";
                
                // Dopo 5 secondi, reindirizza alla pagina di login
                header("refresh:5;url=login.php");
            } else {
                $message = "Si è verificato un errore. Riprova più tardi.";
                $message_type = "error";
            }
        }
    }
    
    $conn->close();
} else {
    $message = "Nessun token fornito. Richiedi un link per reimpostare la password.";
    $message_type = "error";
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reimposta Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
            width: 380px;
            max-width: 100%;
            overflow: hidden;
            padding: 30px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #666;
            font-size: 16px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #444;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            border-color: #764ba2;
            outline: none;
        }
        
        .password-requirements {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            padding: 12px 0;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 14px rgba(0, 0, 0, 0.1);
        }
        
        .login-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        
        .login-link a {
            color: #764ba2;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }
        
        .message.error {
            background-color: #ffe6e6;
            color: #d33;
        }
        
        .message.success {
            background-color: #e6ffe6;
            color: #3c763d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Reimposta Password</h1>
            <p>Crea una nuova password per il tuo account</p>
        </div>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($token_valido): ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?token=' . htmlspecialchars($token); ?>" method="post">
                <div class="form-group">
                    <label for="password">Nuova Password</label>
                    <input type="password" id="password" name="password" placeholder="Crea una nuova password" required>
                    <div class="password-requirements">
                        La password deve contenere almeno 8 caratteri, una lettera maiuscola e un numero
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="conferma-password">Conferma Password</label>
                    <input type="password" id="conferma-password" name="conferma-password" placeholder="Conferma la nuova password" required>
                </div>
                
                <button type="submit" class="btn">Reimposta Password</button>
            </form>
        <?php else: ?>
            <div class="login-link">
                <a href="recupera-password.php">Richiedi un nuovo link</a> o <a href="login.php">torna al login</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>