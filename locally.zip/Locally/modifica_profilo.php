<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "my_locally");
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$user_id = $_SESSION["user_id"];
$email = $_SESSION["email"];
$messaggio = "";
$nome = "";
$cognome = "";

// Recupera dati attuali
$stmt = $conn->prepare("SELECT nome FROM local_u WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nome = $row['nome'];
    $tabella = "local_u";
} else {
    $stmt = $conn->prepare("SELECT nome FROM unlocal_u WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nome = $row['nome'];
        $cognome = $row['cognome'];
        $tabella = "unlocal_u";
    } else {
        $messaggio = "Utente non trovato.";
    }
}

// Gestione modifica
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($tabella)) {
    $nuovo_nome = trim($_POST["nome"]);
    $nuovo_cognome = isset($_POST["cognome"]) ? trim($_POST["cognome"]) : null;

    if ($tabella == "local_u") {
        $stmt = $conn->prepare("UPDATE local_u SET nome = ? WHERE id = ?");
        $stmt->bind_param("si", $nuovo_nome, $user_id);
    } else {
        $stmt = $conn->prepare("UPDATE unlocal_u SET nome = ? WHERE id = ?");
        $stmt->bind_param("si", $nuovo_nome, $user_id);
    }
    if ($stmt->execute()) {
        $messaggio = "Profilo aggiornato con successo!";
        $nome = $nuovo_nome;
        if ($tabella == "unlocal_u") $cognome = $nuovo_cognome;
    } else {
        $messaggio = "Errore durante l'aggiornamento: " . $conn->error;
    }
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Modifica profilo - Locally</title>
    <link rel="icon" type="image/x-icon" href="logo.jpg">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #efe9e2;
            margin: 0;
            min-height: 100vh;
            position: relative;
        }
        .header-logo {
            width: 180px;
            display: block;
            margin: 30px auto 10px auto;
        }
        .slogan {
            text-align: center;
            font-size: 2em;
            color: #5b5c38;
            font-style: italic;
            margin-bottom: 30px;
        }
        .container {
            max-width: 700px;
            margin: 0 auto 40px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
            padding: 30px;
            position: relative;
            z-index: 2;
        }
        .logout {
            float: right;
            background: #764ba2;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group {
            margin-bottom: 18px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            color: #5b5c38;
        }
        input {
            width: 100%;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1em;
        }
        .submit-btn {
            background: #5b5c38;
            color: #fff;
            border: none;
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        .messaggio {
            margin-bottom: 18px;
            color: #764ba2;
            font-weight: bold;
            text-align: center;
        }
        .img-sinistra {
            position: absolute;
            top: 80px;
            left: 0;
            width: 180px;
            border-radius: 0 0 40px 0;
            z-index: 1;
        }
        .img-destra {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 300px;
            border-radius: 40px 0 0 0;
            z-index: 1;
        }
        .img-foto {
            position: absolute;
            top: 30px;
            right: 40px;
            width: 90px;
            opacity: 0.8;
            z-index: 3;
        }
        @media (max-width: 900px) {
            .container { max-width: 98vw; }
            .img-sinistra, .img-destra, .img-foto { display: none; }
            .header-logo { width: 90vw; }
        }
    </style>
</head>
<body>
    <img src="logo.png" alt="Locally Logo" class="header-logo">
    <div class="slogan">Eat like a local</div>
    <img src="foto.jpg" alt="Hand Logo" class="img-foto">
    <img src="sinistra.jpg" alt="Piatto 1" class="img-sinistra">
    <img src="destra.jpg" alt="Piatto 2" class="img-destra">

    <div class="container">
        <form action="logout.php" method="post" style="float:right;">
            <button class="logout" type="submit">Esci</button>
        </form>
        <h1>Modifica profilo</h1>
        <?php if ($messaggio): ?>
            <div class="messaggio"><?php echo htmlspecialchars($messaggio); ?></div>
        <?php endif; ?>
        <form method="post" autocomplete="off">
            <div class="form-group">
                <label for="nome">Nome</label>
                <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>
            </div>
            <?php if ($tabella == "unlocal_u"): ?>
            <div class="form-group">
            </div>
            <?php endif; ?>
            <button class="submit-btn" type="submit">Salva modifiche</button>
        </form>
        <a href="accesso.php" class="nuova-prenotazione" style="margin-top:20px;display:inline-block;">Torna all'area personale</a>
    </div>
</body>
</html>