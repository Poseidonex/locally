<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit();
}

// Connessione al database
$conn = new mysqli("localhost", "root", "", "my_locally");
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Recupera dati utente
$user_id = $_SESSION["user_id"];
$email = $_SESSION["email"];


// Recupera info profilo (corretto per evitare errori con UNION)
$user = null;
$stmt = $conn->prepare("SELECT nome FROM local_u WHERE id = ?");
if (!$stmt) {
    die("Errore nella query local_u: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    $stmt = $conn->prepare("SELECT nome FROM unlocal_u WHERE id = ?");
    if (!$stmt) {
        die("Errore nella query unlocal_u: " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
    }
}

// Recupera prenotazioni (adatta la query secondo la tua struttura)
$prenotazioni = [];
$stmt2 = $conn->prepare("SELECT ristorante, data, ora, stato FROM prenotazioni WHERE user_id = ?");
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$result2 = $stmt2->get_result();
while ($row = $result2->fetch_assoc()) {
    $prenotazioni[] = $row;
}
$stmt->close();
$stmt2->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>La tua area personale - Locally</title>
    <link rel="icon" type="image/x-icon" href="logo.png">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #efe9e2;
            margin: 0;
            min-height: 100vh;
            position: relative;
        }
        .header-logo {
            width: 180px;
            display: block;
            margin: 30px auto 10px auto;
        }
        .slogan {
            text-align: center;
            font-size: 2em;
            color: #5b5c38;
            font-style: italic;
            margin-bottom: 30px;
        }
        .container {
            max-width: 700px;
            margin: 0 auto 40px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
            padding: 30px;
            position: relative;
            z-index: 2;
        }
        .profilo {
            margin-bottom: 30px;
        }
        .profilo strong { color: #764ba2; }
        .prenotazioni { margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #f6f6f6; color: #5b5c38; }
        .logout {
            float: right;
            background: #764ba2;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .nuova-prenotazione {
            display: inline-block;
            margin-top: 10px;
            background: #5b5c38;
            color: #fff;
            padding: 10px 18px;
            border-radius: 5px;
            text-decoration: none;
        }
        /* Immagini decorative */
        .img-sinistra {
            position: absolute;
            top: 80px;
            left: 0;
            width: 180px;
            border-radius: 0 0 40px 0;
            z-index: 1;
        }
        .img-destra {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 300px;
            border-radius: 40px 0 0 0;
            z-index: 1;
        }
        .img-foto {
            position: absolute;
            top: 30px;
            right: 40px;
            width: 90px;
            opacity: 0.8;
            z-index: 3;
        }
        @media (max-width: 900px) {
            .container { max-width: 98vw; }
            .img-sinistra, .img-destra, .img-foto { display: none; }
            .header-logo { width: 90vw; }
        }
    </style>
</head>
<body>
    <img src="logo.png" alt="Locally Logo" class="header-logo">
    <div class="slogan">Eat like a local</div>
    <img src="foto.jpg" alt="Hand Logo" class="img-foto">
    <img src="sinistra.jpg" alt="Piatto 1" class="img-sinistra">
    <img src="destra.jpg" alt="Piatto 2" class="img-destra">

    <div class="container">
        <form action="logout.php" method="post" style="float:right;">
            <button class="logout" type="submit">Esci</button>
        </form>
        <h1>Ciao, <?php echo htmlspecialchars($user['nome'] ?? 'Utente'); ?>!</h1>
        <div class="profilo">
            <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            <?php if (!empty($user['cognome'])): ?>
                <p><strong>Cognome:</strong> <?php echo htmlspecialchars($user['cognome']); ?></p>
            <?php endif; ?>
            <a href="modifica_profilo.php" class="nuova-prenotazione">Modifica profilo</a>
        </div>
        <div class="prenotazioni">
            <h2>Le tue prenotazioni</h2>
            <?php if (count($prenotazioni) > 0): ?>
                <table>
                    <tr>
                        <th>Ristorante</th>
                        <th>Data</th>
                        <th>Ora</th>
                        <th>Stato</th>
                    </tr>
                    <?php foreach ($prenotazioni as $p): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($p['ristorante']); ?></td>
                            <td><?php echo htmlspecialchars($p['data']); ?></td>
                            <td><?php echo htmlspecialchars($p['ora']); ?></td>
                            <td><?php echo htmlspecialchars($p['stato']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <p>Non hai ancora prenotazioni.</p>
            <?php endif; ?>
            <a href="prenota.php" class="nuova-prenotazione">Prenota un nuovo ristorante</a>
        </div>
    </div>
</body>
</html>