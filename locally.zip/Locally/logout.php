<?php
session_start();
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Logout - Locally</title>
    <link rel="icon" type="image/x-icon" href="logo.jpg">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #efe9e2;
            margin: 0;
            min-height: 100vh;
            position: relative;
        }
        .header-logo {
            width: 180px;
            display: block;
            margin: 30px auto 10px auto;
        }
        .slogan {
            text-align: center;
            font-size: 2em;
            color: #5b5c38;
            font-style: italic;
            margin-bottom: 30px;
        }
        .container {
            max-width: 700px;
            margin: 0 auto 40px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
            padding: 30px;
            position: relative;
            z-index: 2;
            text-align: center;
        }
        .img-sinistra {
            position: absolute;
            top: 80px;
            left: 0;
            width: 180px;
            border-radius: 0 0 40px 0;
            z-index: 1;
        }
        .img-destra {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 300px;
            border-radius: 40px 0 0 0;
            z-index: 1;
        }
        .img-foto {
            position: absolute;
            top: 30px;
            right: 40px;
            width: 90px;
            opacity: 0.8;
            z-index: 3;
        }
        .btn-home {
            display: inline-block;
            margin-top: 30px;
            background: #5b5c38;
            color: #fff;
            padding: 10px 18px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 1.1em;
        }
        @media (max-width: 900px) {
            .container { max-width: 98vw; }
            .img-sinistra, .img-destra, .img-foto { display: none; }
            .header-logo { width: 90vw; }
        }
    </style>
</head>
<body>
    <img src="logo.png" alt="Locally Logo" class="header-logo">
    <div class="slogan">Eat like a local</div>
    <img src="foto.jpg" alt="Hand Logo" class="img-foto">
    <img src="sinistra.jpg" alt="Piatto 1" class="img-sinistra">
    <img src="destra.jpg" alt="Piatto 2" class="img-destra">

    <div class="container">
        <h1>Logout effettuato</h1>
        <p>Hai effettuato il logout con successo.<br>
        Grazie per aver usato Locally!</p>
        <a href="index.php" class="btn-home">Torna alla Home</a>
    </div>
</body>
</html>