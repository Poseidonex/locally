<?php
// Inizializza le variabili
$email = $password = "";
$error = "";

// Verifica se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera e pulisce i dati del form
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $login_type = isset($_POST['login_type']) ? $_POST['login_type'] : '';
    if ( ($login_type === 'unlocal') ){
    $table = 'unlocal_u';
    }else{
    $table = 'local_u';
    }
    
    // Qui inserisci la logica di validazione e autenticazione
    if (empty($email) || empty($password) || empty($login_type)|| $login_type === '') {
        $error = "Inserisci email e password e seleziona il tipo di login.";
    } else {
        // Esempio di connessione al database (da personalizzare con i tuoi parametri)
        //$conn = new mysqli("sql7.freesqldatabase.com", "sql7780058", "SwidxqPSdb", "sql7780058");
          $conn = new mysqli("localhost", "root", "", "my_locally");
        // Verifica la connessione
        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }
        
        // Prepara la query usando prepared statement per prevenire SQL injection
        $stmt = $conn->prepare("SELECT id, password FROM $table WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            // Verifica la password (assumendo che sia hashata con password_hash())
            if (password_verify($password, $user["password"])) {
                // Password corretta, inizia la sessione
                session_start();
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["email"] = $email;
                
                // Reindirizza alla pagina dashboard o home
                header("Location: accesso.php");
                exit();
            } else {
                $error = "Email o password non validii";
            }
        } else {
            $error = "Email o password non validi";
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locally</title>
     <link rel="icon" type="image/x-icon" href="logo.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #efe9e2;
            height: 100vh;
            position: relative;
            
        }
        .patate{
            position:absolute;
            bottom:-30%;
            height:auto;
            width:100%;
        }
        .container {
            
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
            width: 17%;
            max-width: 100%;
            overflow: hidden;
            padding: 30px;
            margin:30%;
            
        }
        .aiuto{
            width: 100%;
            height:100%;
            display:flex;
            align-items:center;
            justify-content:right;
        }
        .titolo{
            position: absolute;
            top:5%;
            left:20%;
            
    
        }
        .img{
            width:30%;
            height: 30%;
        }       
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #5b5c38;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #666;
            font-size: 16px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #444;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            border-color: #764ba2;
            outline: none;
        }
        
        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .remember-forgot label {
            display: flex;
            align-items: center;
        }
        
        .remember-forgot input {
            margin-right: 5px;
        }
        
        .remember-forgot a {
            color: #764ba2;
            text-decoration: none;
        }
        
        .remember-forgot a:hover {
            text-decoration: underline;
        }
        .main{
            position: absolute;
            width: 17%;
            top: 35%;
            left: 20%;
            display: flex;
            flex-direction: row;
        }
        button{
            background: #5b5c38;
            color: white;
            border: none;
            padding: 12px 0;
            width: 100%;
            border-radius: 5px;
            font-size: 20px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            margin:5px;
        }
        
        .btn {
            background: #5b5c38;
            color: white;
            border: none;
            padding: 12px 0;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        button:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 14px rgba(0, 0, 0, 0.1);
        }
        
        
        .cliccato {
      background:rgb(65, 65, 50);
    }
        .signup {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        
        .signup a {
            color: #764ba2;
            text-decoration: none;
            font-weight: 600;
        }
        
        .signup a:hover {
            text-decoration: underline;
        }
        
        .error-message {
            background-color: #ffe6e6;
            color: #d33;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="titolo">
            <img src="titolo.jpg" alt="" class="img">
        </div>
        <div class="main">
                <button type="button" id="mioBottone1" >LOCAL</button>
                <button type="button" id="mioBottone">UNLOCAL</button>
        </div>
        
        <img src="patate.jpg" alt="" class="patate">
        <div class="aiuto">
            <div class="container">
        <div class="header">
            <h1>LOGIN a LOCALLY </h1>
            <p>Accedi al tuo account</p>
        </div>

        
        
        <?php if (!empty($error)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" id="loginForm">
        <input type="hidden" name="login_type" id="login_type" value="">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Inserisci la tua email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Inserisci la tua password" required>
            </div>
            
            <div class="remember-forgot">
                <label>
                    <input type="checkbox" name="remember"> Ricordami
                </label>
                <a href="recupera-password.php">Password dimenticata?</a>
            </div>
            
            <a href="primapg.php"><button type="submit" class="btn">Accedi</button></a>
            
            <div class="signup">
                Non hai un account? <a href="registrati.php">Registrati</a>
            </div>
        </form>
    </div>
        </div>
<script>
    const bottone = document.getElementById("mioBottone");
    const bottone1 = document.getElementById("mioBottone1");
    const loginTypeInput = document.getElementById("login_type");
  bottone.addEventListener("click", function () {
    // Controlla se ha già la classe "cliccato"
    if (bottone.classList.contains("cliccato")) {
      // Torna allo stato originale
      bottone.classList.remove("cliccato");
      loginTypeInput.value = "";

    }  else if(bottone1.classList.contains("cliccato")){
        bottone1.classList.remove("cliccato");

        bottone.classList.add("cliccato");
        loginTypeInput.value = "unlocal";


    }
    else {
      // Cambia aspetto
      bottone.classList.add("cliccato");
      loginTypeInput.value = "unlocal";
    }
  });


  bottone1.addEventListener("click", function () {
    // Controlla se ha già la classe "cliccato"
    if (bottone1.classList.contains("cliccato")) {
      // Torna allo stato originale
      bottone1.classList.remove("cliccato");
      loginTypeInput.value = "";
    }else if(bottone.classList.contains("cliccato")){
        bottone.classList.remove("cliccato");
        bottone1.classList.add("cliccato");
        loginTypeInput.value = "local";


    }
    else {
      // Cambia aspetto
      bottone1.classList.add("cliccato");
      loginTypeInput.value = "local";
    }
  });
</script>
</body>
</html>